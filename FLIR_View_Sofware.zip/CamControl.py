import pygame
import sys
import socket
import json
import threading

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
NUMBER_BUTTON_WIDTH, NUMBER_BUTTON_HEIGHT = 40, 40
BUTTON_WIDTH, BUTTON_HEIGHT = 150, 50
GRID_ROWS, GRID_COLS = 3, 8
LEFT_PANEL_WIDTH = 200

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (0, 0, 255)

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("FLIR View Remote")

# Fonts
font = pygame.font.Font(None, 36)


# Button class
class Button:
    def __init__(self, rect, text, callback=None):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.color = GRAY
        self.text_surface = font.render(text, True, BLACK)
        self.text_rect = self.text_surface.get_rect(center=self.rect.center)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect)
        screen.blit(self.text_surface, self.text_rect)

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)


# InputBox class
class InputBox:
    def __init__(self, x, y, w, h, text=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = GRAY
        self.text = text
        self.txt_surface = font.render(text, True, BLACK)
        self.active = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # If the user clicked on the input box rect.
            if self.rect.collidepoint(event.pos):
                # Toggle the active variable.
                self.active = not self.active
            else:
                self.active = False
            self.color = BLUE if self.active else GRAY
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    print(self.text)
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                # Re-render the text.
                self.txt_surface = font.render(self.text, True, BLACK)

    def update(self):
        # Resize the box if the text is too long.
        width = max(200, self.txt_surface.get_width()+10)
        self.rect.w = width

    def draw(self, screen):
        # Blit the text.
        screen.blit(self.txt_surface, (self.rect.x+5, self.rect.y+5))
        # Blit the rect.
        pygame.draw.rect(screen, self.color, self.rect, 2)


# Callback functions
def select_button(number):
    global selected_button
    selected_button = number
    state['selected_button'] = number
    state['raw_video'] = False
    send_state()


def toggle_crosshair():
    state['crosshair'] = not state['crosshair']
    state['tree'] = False
    send_state()


def toggle_tree():
    state['tree'] = not state['tree']
    state['crosshair'] = False
    send_state()


def toggle_invert_heatmap():
    state['invert_heatmap'] = not state['invert_heatmap']
    send_state()


def toggle_raw_video():
    state['raw_video'] = not state['raw_video']
    state['selected_button'] = None
    send_state()


def toggle_overlays():
    state['crosshair'] = False
    state['tree'] = False
    state['timestamp'] = False
    send_state()


def toggle_timestamp():
    state['timestamp'] = not state['timestamp']
    send_state()


def connect_to_server():
    global client_socket, connected
    ip = ip_box.text
    port = int(port_box.text)
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((ip, port))
        print(f"Connected to server {ip}:{port}")
        connected = True
    except Exception as e:
        print(f"Failed to connect to server: {e}")
        connected = False


# Function to send state to server
def send_state():
    if connected:
        state_json = json.dumps(state)
        client_socket.sendall(state_json.encode('utf-8'))


# Initialize buttons
buttons = []
state = {'selected_button': None, 'crosshair': False, 'tree': False, 'invert_heatmap': False, 'raw_video': False, 'timestamp': False}
selected_button = None
connected = False

# Create grid buttons
for i in range(GRID_ROWS):
    for j in range(GRID_COLS):
        if i * GRID_COLS + j > 21:
            break
        rect = (WIDTH - (GRID_COLS - j) * (NUMBER_BUTTON_WIDTH + 10), 10 + i * (NUMBER_BUTTON_HEIGHT + 10), NUMBER_BUTTON_WIDTH, NUMBER_BUTTON_HEIGHT)
        button = Button(rect, str(i * GRID_COLS + j), lambda x=i * GRID_COLS + j: select_button(x))
        buttons.append(button)

# Create left panel buttons
left_panel_buttons = [
    Button((10, 10, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Crosshair", toggle_crosshair),
    Button((10, 70, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Tree", toggle_tree),
    Button((10, 130, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Invert Heatmap", toggle_invert_heatmap),
    Button((10, 190, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Raw Video", toggle_raw_video),
]

# Create middle buttons
middle_buttons = [
    Button((WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 - BUTTON_HEIGHT - 10, BUTTON_WIDTH, BUTTON_HEIGHT), "Overlays On/Off", toggle_overlays),
    Button((WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 + 10, BUTTON_WIDTH, BUTTON_HEIGHT), "Timestamp", toggle_timestamp),
]

# Create IP and Port input boxes and connect button
ip_box = InputBox(WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 - BUTTON_HEIGHT - 10, 100, 40)
port_box = InputBox(WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 + 10, 100, 40)
connect_button = Button((WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 + 70, BUTTON_WIDTH, BUTTON_HEIGHT), "Connect", connect_to_server)

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            for button in buttons:
                if button.is_clicked(pos):
                    button.callback()
            for button in left_panel_buttons:
                if button.is_clicked(pos):
                    button.callback()
            for button in middle_buttons:
                if button.is_clicked(pos):
                    button.callback()
            if connect_button.is_clicked(pos):
                connect_button.callback()
        ip_box.handle_event(event)
        port_box.handle_event(event)

    # Drawing
    screen.fill(WHITE)

    for button in buttons:
        button.draw(screen)

    for button in left_panel_buttons:
        button.draw(screen)

    for button in middle_buttons:
        button.draw(screen)

    ip_box.update()
    port_box.update()

    ip_box.draw(screen)
    port_box.draw(screen)
    connect_button.draw(screen)

    # Draw labels for IP and Port input boxes
    ip_label = font.render("IP Address:", True, BLACK)
    screen.blit(ip_label, (WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 - BUTTON_HEIGHT - 40))
    port_label = font.render("Port Number:", True, BLACK)
    screen.blit(port_label, (WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 - 20))

    # Draw connection status
    connection_status = f"Connected: {connected}"
    connection_status_surface = font.render(connection_status, True, BLACK)
    screen.blit(connection_status_surface, (WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 + 120))

    # Display selected button and states
    status_text = f"Selected Button: {state['selected_button']}"
    status_surface = font.render(status_text, True, BLACK)
    screen.blit(status_surface, (10, HEIGHT - 30))

    crosshair_text = f"Crosshair: {'ON' if state['crosshair'] else 'OFF'}"
    crosshair_surface = font.render(crosshair_text, True, BLACK)
    screen.blit(crosshair_surface, (10, HEIGHT - 60))

    tree_text = f"Tree: {'ON' if state['tree'] else 'OFF'}"
    tree_surface = font.render(tree_text, True, BLACK)
    screen.blit(tree_surface, (10, HEIGHT - 90))

    invert_heatmap_text = f"Invert Heatmap: {'ON' if state['invert_heatmap'] else 'OFF'}"
    invert_heatmap_surface = font.render(invert_heatmap_text, True, BLACK)
    screen.blit(invert_heatmap_surface, (10, HEIGHT - 120))

    raw_video_text = f"Raw Video: {'ON' if state['raw_video'] else 'OFF'}"
    raw_video_surface = font.render(raw_video_text, True, BLACK)
    screen.blit(raw_video_surface, (10, HEIGHT - 150))

    timestamp_text = f"Timestamp: {'ON' if state['timestamp'] else 'OFF'}"
    timestamp_surface = font.render(timestamp_text, True, BLACK)
    screen.blit(timestamp_surface, (10, HEIGHT - 180))

    pygame.display.flip()

pygame.quit()
if connected:
    client_socket.close()
sys.exit()


def toggle_tree():
    state['tree'] = not state['tree']
    send_state()


def toggle_invert_heatmap():
    state['invert_heatmap'] = not state['invert_heatmap']
    send_state()


def toggle_raw_video():
    state['raw_video'] = not state['raw_video']
    send_state()


def toggle_overlays():
    state['crosshair'] = False
    state['tree'] = False
    state['timestamp'] = False
    send_state()


def toggle_timestamp():
    state['timestamp'] = not state['timestamp']
    send_state()


def connect_to_server():
    global client_socket, connected
    ip = ip_box.text
    port = int(port_box.text)
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((ip, port))
        print(f"Connected to server {ip}:{port}")
        connected = True
    except Exception as e:
        print(f"Failed to connect to server: {e}")
        connected = False


# Function to send state to server
def send_state():
    if connected:
        state_json = json.dumps(state)
        client_socket.sendall(state_json.encode('utf-8'))


# Initialize buttons
buttons = []
state = {'selected_button': None, 'crosshair': False, 'tree': False, 'invert_heatmap': False, 'raw_video': False, 'timestamp': False}
selected_button = None
connected = False

# Create grid buttons
for i in range(GRID_ROWS):
    for j in range(GRID_COLS):
        if i * GRID_COLS + j > 21:
            break
        rect = (WIDTH - (GRID_COLS - j) * (NUMBER_BUTTON_WIDTH + 10), 10 + i * (NUMBER_BUTTON_HEIGHT + 10), NUMBER_BUTTON_WIDTH, NUMBER_BUTTON_HEIGHT)
        button = Button(rect, str(i * GRID_COLS + j), lambda x=i * GRID_COLS + j: select_button(x))
        buttons.append(button)

# Create left panel buttons
left_panel_buttons = [
    Button((10, 10, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Crosshair", toggle_crosshair),
    Button((10, 70, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Tree", toggle_tree),
    Button((10, 130, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Invert Heatmap", toggle_invert_heatmap),
    Button((10, 190, LEFT_PANEL_WIDTH - 20, BUTTON_HEIGHT), "Raw Video", toggle_raw_video),
]

# Create middle buttons
middle_buttons = [
    Button((WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 - BUTTON_HEIGHT - 10, BUTTON_WIDTH, BUTTON_HEIGHT), "Overlays On/Off", toggle_overlays),
    Button((WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 + 10, BUTTON_WIDTH, BUTTON_HEIGHT), "Timestamp", toggle_timestamp),
]

# Create IP and Port input boxes and connect button
ip_box = InputBox(WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 - BUTTON_HEIGHT - 10, 100, 40)
port_box = InputBox(WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 + 10, 100, 40)
connect_button = Button((WIDTH // 2 + BUTTON_WIDTH // 2 + 20, HEIGHT // 2 + 70, BUTTON_WIDTH, BUTTON_HEIGHT), "Connect", connect_to_server)

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            for button in buttons:
                if button.is_clicked(pos):
                    button.callback()
            for button in left_panel_buttons:
                if button.is_clicked(pos):
                    button.callback()
            for button in middle_buttons:
                if button.is_clicked(pos):
                    button.callback()
            if connect_button.is_clicked(pos):
                connect_button.callback()
        ip_box.handle_event(event)
        port_box.handle_event(event)

    # Drawing
    screen.fill(WHITE)

    for button in buttons:
        button.draw(screen)

    for button in left_panel_buttons:
        button.draw(screen)

    for button in middle_buttons:
        button.draw(screen)

    ip_box.update()
    port_box.update()

    ip_box.draw(screen)
    port_box.draw(screen)
    connect_button.draw(screen)

    # Display selected button and states
    status_text = f"Selected Button: {state['selected_button']}"
    status_surface = font.render(status_text, True, BLACK)
    screen.blit(status_surface, (10, HEIGHT - 30))

    crosshair_text = f"Crosshair: {'ON' if state['crosshair'] else 'OFF'}"
    crosshair_surface = font.render(crosshair_text, True, BLACK)
    screen.blit(crosshair_surface, (10, HEIGHT - 60))

    tree_text = f"Tree: {'ON' if state['tree'] else 'OFF'}"
    tree_surface = font.render(tree_text, True, BLACK)
    screen.blit(tree_surface, (10, HEIGHT - 90))

    invert_heatmap_text = f"Invert Heatmap: {'ON' if state['invert_heatmap'] else 'OFF'}"
    invert_heatmap_surface = font.render(invert_heatmap_text, True, BLACK)
    screen.blit(invert_heatmap_surface, (10, HEIGHT - 120))

    raw_video_text = f"Raw Video: {'ON' if state['raw_video'] else 'OFF'}"
    raw_video_surface = font.render(raw_video_text, True, BLACK)
    screen.blit(raw_video_surface, (10, HEIGHT - 150))

    timestamp_text = f"Timestamp: {'ON' if state['timestamp'] else 'OFF'}"
    timestamp_surface = font.render(timestamp_text, True, BLACK)
    screen.blit(timestamp_surface, (10, HEIGHT - 180))

    pygame.display.flip()

pygame.quit()
if connected:
    client_socket.close()
sys.exit()
