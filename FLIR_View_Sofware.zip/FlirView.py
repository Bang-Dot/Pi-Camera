#!/usr/bin/env python3
import threading
import argparse
import configparser
from datetime import datetime, timezone
import socket
import json
import select
# 3rd Party imports
import numpy as np
import gi
import cv2
gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
# import after above function calls to silence warnings
from gi.repository import Gst, GstRtspServer, GLib


class RemoteServer(threading.Thread):
    def __init__(self, ip_address: str='0.0.0.0', port: int=65432):
        threading.Thread.__init__(self)
        self.daemon = True
        self.HOST = ip_address  # Localhost
        self.PORT = port        # Port to listen on
        self.state = {}

    def get_state(self):
        return self.state

    def run(self):
        # Create a socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((self.HOST, self.PORT))
        server_socket.listen()
        server_socket.setblocking(0)  # Set to non-blocking

        print(f"Server listening on {self.HOST}:{self.PORT}")

        inputs = [server_socket]
        client_sockets = {}

        try:
            while True:
                readable, _, exceptional = select.select(inputs, [], inputs)

                for s in readable:
                    if s is server_socket:
                        # Handle new connection
                        conn, addr = server_socket.accept()
                        print(f"Connected by {addr}")
                        conn.setblocking(0)
                        inputs.append(conn)
                        client_sockets[conn] = addr
                    else:
                        data = s.recv(1024)
                        if data:
                            # Decode the received JSON string
                            self.state = json.loads(data.decode('utf-8'))
                        else:
                            # Client disconnected
                            print(f"Client {client_sockets[s]} disconnected")
                            inputs.remove(s)
                            s.close()
                            del client_sockets[s]

                for s in exceptional:
                    print(f"Handling exceptional condition for {client_sockets[s]}")
                    inputs.remove(s)
                    s.close()
                    del client_sockets[s]

        except Exception as e:
            print(f"Server error: {e}")
        finally:
            server_socket.close()


class RtspSystem(GstRtspServer.RTSPMediaFactory):
    def __init__(self, cam_x, cam_y, **properties):
        super(RtspSystem, self).__init__(**properties)
        self.cam_x = cam_x
        self.cam_y = cam_y
        self.data = None
        self.number_frames = 0
        fps = 59
        """ # here as a possible other option if there are issues with rtsp consumer
        self.launch_string = 'appsrc name=source is-live=true block=true format=GST_FORMAT_TIME ' \
                             'caps=video/x-raw,format=BGR,width={},height={},framerate={}/1 ' \
                             '! videoconvert ! video/x-raw,format=I420 ' \
                             '! x264enc speed-preset=ultrafast tune=zerolatency ' \
                             '! rtph264pay config-interval=0 name=pay0 pt=96'.format(self.cam_x, self.cam_y, fps)

        """
        self.launch_string = 'appsrc name=source is-live=true block=true format=GST_FORMAT_TIME ' \
                             'caps=video/x-raw,format=BGR,width={},height={},framerate={}/1 ' \
                             '! videoconvert ! video/x-raw,format=I420 ' \
                             '! x264enc speed-preset=ultrafast tune=zerolatency bitrate=500 ' \
                             '! rtph264pay config-interval=1 name=pay0 pt=96'.format(self.cam_x, self.cam_y, fps)

    def send_data(self, data):
        self.data = data

    def start(self):
        t = threading.Thread(target=self._thread_rtsp)
        t.start()

    def _thread_rtsp(self):
        loop = GLib.MainLoop()
        loop.run()

    def on_need_data(self, src, length):
        if self.data is not None:
            retval = src.emit('push-buffer', Gst.Buffer.new_wrapped(self.data.tobytes()))
            if retval != Gst.FlowReturn.OK:
                print(retval)

    def do_create_element(self, url):
        return Gst.parse_launch(self.launch_string)

    def do_configure(self, rtsp_media):
        self.number_frames = 0
        appsrc = rtsp_media.get_element().get_child_by_name('source')
        appsrc.set_property("emit-signals", True)
        appsrc.connect('need-data', self.on_need_data)


class RTSPServer(GstRtspServer.RTSPServer):
    def __init__(self, cam_x=640, cam_y=480, port=8554, factory="/FLIR", **properties):
        super(RTSPServer, self).__init__(**properties)
        self.cam_x = cam_x
        self.cam_y = cam_y
        self.rtsp = RtspSystem(self.cam_x, self.cam_y)
        self.rtsp.set_shared(True)
        self.set_service(str(port))
        self.overlay = self.null_function
        self.c_map = None
        if not factory.startswith('/'):
            factory = '/' + factory
        self.get_mount_points().add_factory(factory, self.rtsp)
        self.attach(None)
        Gst.init(None)
        self.color = (0, 255, 255)  # Yellow color in BGR
        self.rtsp.start()
        self.raw = True
        self.timestamp = False
        self.invert = False
        self.tree = False
        self.crosshair = False
        # List of available colormaps in OpenCV
        self.colormaps = [
            cv2.COLORMAP_AUTUMN, cv2.COLORMAP_BONE, cv2.COLORMAP_JET, cv2.COLORMAP_WINTER,
            cv2.COLORMAP_RAINBOW, cv2.COLORMAP_OCEAN, cv2.COLORMAP_SUMMER, cv2.COLORMAP_SPRING,
            cv2.COLORMAP_COOL, cv2.COLORMAP_HSV, cv2.COLORMAP_PINK, cv2.COLORMAP_HOT,
            cv2.COLORMAP_PARULA, cv2.COLORMAP_MAGMA, cv2.COLORMAP_INFERNO, cv2.COLORMAP_PLASMA,
            cv2.COLORMAP_VIRIDIS, cv2.COLORMAP_CIVIDIS, cv2.COLORMAP_TWILIGHT, cv2.COLORMAP_TWILIGHT_SHIFTED,
            cv2.COLORMAP_TURBO, cv2.COLORMAP_DEEPGREEN
        ]
        print(f"RTSP Server Started on port {port} and factory {factory}")

    def set_timestamp(self, option: bool):
        # toggle raw on and off
        self.timestamp = option

    def set_invert(self, option: bool):
        # toggle raw on and off
        self.invert = option

    def set_raw(self, option: bool):
        # toggle raw on and off
        self.raw = option

    def set_crosshair(self, option: bool):
        if option is True:
            if self.tree is False:
                self.overlay = self.draw_crosshair
                self.crosshair = True
        elif option is False:
            self.crosshair = False
            if self.tree is False:
                self.overlay = self.null_function

    def set_tree(self, option: bool):
        if option is True:
            if self.crosshair is False:
                self.overlay = self.draw_tree
                self.tree = True
        elif option is False:
            self.tree = False
            if self.crosshair is False:
                self.overlay = self.null_function

    def set_color_map(self, cmap: int):
        # we want colors to set raw to false
        self.raw = False
        # set the color map
        self.c_map = self.colormaps[cmap]

    def null_function(self, image):
        # take an image and no nothing with it
        return image

    def draw_crosshair(self, image):
        # take an image and draw a crosshair on it
        # Get image dimensions
        c_height, c_width, _ = image.shape
        # Define crosshair properties
        center_x, center_y = c_width // 2, c_height // 2
        length = 40
        thickness = 2
        alpha = 0.6  # Transparency factor
        # Create a copy of the image to draw on
        overlay = image.copy()
        # Draw horizontal and vertical lines
        cv2.line(overlay, (center_x - length, center_y), (center_x + length, center_y), self.color, thickness)
        cv2.line(overlay, (center_x, center_y - length), (center_x, center_y + length), self.color, thickness)
        # Blend the overlay with the original image
        cv2.addWeighted(overlay, alpha, image, 1 - alpha, 0, image)
        return image

    def draw_tree(self, image):
        # take an image and draw a 5 bar tree on it
        t_height, t_width, _ = image.shape
        overlay = image.copy()
        # Define the number of lines and the spacing (half the previous spacing)
        num_lines = 5
        line_height_total = num_lines * 20  # height occupied by lines
        spacing = 10  # spacing between lines
        total_height = line_height_total + spacing * (num_lines - 1)
        # Calculate the starting y position to center the lines vertically
        start_y = (t_height - total_height) // 2
        # Calculate line lengths (top line shortest, bottom line longest)
        line_lengths = np.linspace(t_width // 4, t_width // 2, num_lines)
        # Draw the lines on the overlay image
        for i in range(num_lines):
            start_x = int((t_width - line_lengths[i]) // 2)
            end_x = int((t_width + line_lengths[i]) // 2)
            y = start_y + i * (20 + spacing)
            cv2.line(overlay, (start_x, y), (end_x, y), self.color, 2)
        # Blend the overlay with the original image
        alpha = 0.5  # Transparency factor
        cv2.addWeighted(overlay, alpha, image, 1 - alpha, 0, image)
        return image

    def write_time_stamp(self, image):
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        cv2.putText(image, timestamp, (10, height - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2, cv2.LINE_AA)
        return image

    def prep_image(self, image):
        # apply overlays and resize and invert if needed
        if self.invert is True:
            image = cv2.bitwise_not(image)
        if self.raw is False and self.c_map is not None:
            image = cv2.applyColorMap(image, self.c_map)
        # apply any overlay if they are enabled
        image = self.overlay(image)
        # apply a timestamp if its enabled
        if self.timestamp is True:
            self.write_time_stamp(image)
        return cv2.resize(image, (self.cam_x, self.cam_y))

    def send_data(self, data):
        # Prep and send out a frame
        self.rtsp.send_data(self.prep_image(data))


def set_values(rserver, vdict):
    # configure the server with initial configs
    rtsp_server.set_invert(vdict.get('invert_heatmap', False))
    rtsp_server.set_tree(vdict.get('tree', False))
    rtsp_server.set_crosshair(vdict.get('crosshair', False))
    rtsp_server.set_raw(vdict.get('raw_video', True))
    if args.colormap is not None or vdict.get('selected_button', None) is not None:
        rtsp_server.set_color_map(int(vdict.get('selected_button', None)))
    rtsp_server.set_timestamp(vdict.get('timestamp', False))



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RTSP Server Configuration")
    parser.add_argument('--config', type=str, help='Path to config file', default=None)
    parser.add_argument('--video', '-v', type=str, default='/dev/video0',
                        help='The video device or file to use (e.g., /dev/video0). Default is /dev/video0.')
    parser.add_argument('--port', '-p', type=int, default=8554,
                        help='The port number to run the RTSP server on. Default is 8554.')
    parser.add_argument('--factory', '-f', type=str, default='/FLIR',
                        help='The RTSP factory path (e.g., /RTSP). Default is /FLIR.')
    parser.add_argument('--timestamp', action='store_true',
                        help='Toggle the timestamp on the video stream. Default is off.')
    overlay_group = parser.add_mutually_exclusive_group()
    overlay_group.add_argument('--crosshair', action='store_true',
                               help='Toggle the crosshair on the video stream. Default is off.')
    overlay_group.add_argument('--tree', action='store_true',
                               help='Toggle the tree drawing on the video stream. Default is off.')
    color_group = parser.add_mutually_exclusive_group()
    color_group.add_argument('--colormap', '-c', type=int, choices=range(21),
                             help=f'Set the colormap (0-21) for the video stream.')
    color_group.add_argument('--raw', action='store_true', default=True,
                             help='Display the raw video stream without any colormap. Default is on.')
    parser.add_argument('--invert', action='store_true',
                        help='Invert the colors before applying the colormap. Default is off.')
    args = parser.parse_args()

    if args.config:
        config = configparser.ConfigParser()
        config.read(args.config)
        if 'RTSP' in config:
            print("Config file in use and will override any other arguments")
            args.video = config['RTSP'].get('video', args.video)
            args.port = config['RTSP'].getint('port', args.port)
            args.factory = config['RTSP'].get('factory', args.factory)
            args.timestamp = config['RTSP'].getboolean('timestamp', args.timestamp)
            args.crosshair = config['RTSP'].getboolean('crosshair', args.crosshair)
            args.tree = config['RTSP'].getboolean('tree', args.tree)
            try:
                args.colormap = config['RTSP'].getint('colormap', args.colormap)
            except ValueError:
                args.colormap = None
            args.raw = config['RTSP'].getboolean('raw', args.raw)
            args.invert = config['RTSP'].getboolean('invert', args.invert)

    rtsp_server = RTSPServer(port=args.port, factory=args.factory)
    # quick and dirty hack to enable remote control
    qd = {'selected_button': args.colormap, 'crosshair': args.crosshair, 'tree': args.tree, 'invert_heatmap': args.invert, 'raw_video': args.raw, 'timestamp': args.timestamp}
    # configure the server with initial configs
    set_values(rtsp_server, qd)
    # Open video capture device
    cap = cv2.VideoCapture(args.video)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    remote = RemoteServer()
    remote.start()
    if not cap.isOpened():
        print(f"Error: Could not open video device {args.video}")

    while True:
        u = remote.get_state()
        if u == {}:
            u = qd
        set_values(rtsp_server, u)
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read image")
            break
        rtsp_server.send_data(frame)
    cap.release()
